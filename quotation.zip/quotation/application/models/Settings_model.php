<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Settings_model extends CI_Model {

    // Insert company settings
    public function insert_company_settings($data) {
        return $this->db->insert('company', $data);
    }
}
