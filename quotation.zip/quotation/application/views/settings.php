<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quotation</title>
     <?php $this->load->view('head') ?>
     <style>
        #company-logo{
            height: 100px;
        }
     </style>
</head>
<body>
<div class="overlay" id="overlay"></div>
    <!-- Sidebar -->
    <?php $this->load->view('sidebar') ?>


    <!-- Content -->
    <div class="content">
        <?php $this->load->view('header') ?>

    <div class="container Custom-body">
      <h2 class="text-center mb-4">Setting</h2>

    <form id="companyForm">
                <!-- Your existing form content goes here -->
        <div class="row">
          <div class="col-md-12">
          <div class="card">
          <div class="card-body">
              <div class="row">
                <div class="col-md-3">
                 <img src="<?=base_url()?>assets/images/photo.png" alt="" class="img-fluid" id="company-logo">
                 <div class="col-md-6 mb-3">
                    <label for="address" class="form-label">Company Logo</label>
                    <input type="file" class="" id="company_logo" name="company_logo" placeholder="Company Logo" required>
                  </div>
                </div>
                <div class="col-md-9">
                  <div class="row">
                  <div class="col-md-4 mb-3">
                    <label for="" class="form-label">Company Brand</label>
                    <input type="text" class="form-control" id="comapny_brand" name="comapny_brand" placeholder="Quotation Name" required>
                  </div>
                  <div class="col-md-4 mb-3">
                    <label for="" class="form-label">Company Email</label>
                    <input type="email" class="form-control" id="comapny_email" name="comapny_email" placeholder="Quotation Email" required>
                  </div>
                  <div class="col-md-4 mb-3">
                    <label for="address" class="form-label">Company Number</label>
                    <input type="number" class="form-control" id="company_number" name="company_number" placeholder="Company Number" required>
                  </div>
                  
                  <div class="col-md-12 mb-3">
                    <label for="" class="form-label">Company Address</label>
                    <textarea class="form-control" id="company_address" name="company_address" placeholder="Company Address" required></textarea>
                   </div>
                   </div>
                 </div>
                 <div class="card-footer mt-2">
                 <div class="d-flex align-items-center">
                <button type="submit" class="btn btn-primary btn-sm">Save</button>
                </div>
                 </div>
                </div>
              </div>
             </div>
            </div>
                    
                </div>
                
            </form>



            <div class="row mt-3">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h2 class="text-center">Terms And Condition</h2>
                        </div>
                        <div class="card-body">
                        <form action="" id="termcondition">
                           <div class="form-group">
                            <textarea name="term_text" id="editor"></textarea>
                           </div>
   
                            <div class="card-footer">
                            <button type="submit" class="btn btn-primary">Submit</button>
                              </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    

      
    </div>

    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.ckeditor.com/ckeditor5/36.0.1/classic/ckeditor.js"></script>

    <script>
        // Sidebar toggle functionality
        $(document).ready(function () {
            $('#toggleSidebar').on('click', function () {
                $('#sidebar').toggleClass('active');
                $('#overlay').toggleClass('active');
            });

            $('#overlay').on('click', function () {
                $('#sidebar').removeClass('active');
                $('#overlay').removeClass('active');
            });
        });
        $('#companyForm').on('submit', function (e) {
    e.preventDefault();

    let formData = new FormData(this);

    // Debug the data being sent
    for (var pair of formData.entries()) {
        console.log(pair[0] + ': ' + pair[1]);
    }

    $.ajax({
        url: 'Settings/save_company_settings',
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        dataType: 'json',
        success: function (response) {
            console.log(response);
            if (response.status === 'success') {
                alert(response.message);
                $('#companyForm')[0].reset(); // Reset the form
            } else {
                alert(response.message);
            }
        },
        error: function (xhr, status, error) {
            console.error(xhr.responseText);
            alert('An error occurred while saving company settings.');
        }
    });
});

    </script>



<script>
    $(document).ready(function () {
        $("#termcondition").on("submit", function (e) {
            e.preventDefault(); // Form submit prevent karein
            $.ajax({
                url: "<?= base_url('conditions/save_conditions') ?>", // CodeIgniter controller method
                type: "POST",
                data: $(this).serialize(),
                dataType: "json",
                success: function (response) {
                    if (response.status == "success") {
                        alert("Conditions added successfully!");
                        $("#termcondition")[0].reset(); // Form reset
                    } else {
                        alert("Failed to add conditions.");
                    }
                },
                error: function () {
                    alert("An error occurred.");
                }
            });
        });
    });
</script>
</body>
</html>



<script>
    // ClassicEditor
    //     .create(document.querySelector('#editor'))
    //     .catch(error => {
    //         console.error(error);
    //     });


    ClassicEditor
    .create(document.querySelector('#editor'), {
        toolbar: ['bold', 'italic', 'link', 'bulletedList', 'numberedList', 'blockQuote'],
        height: 1100
    })
    .catch(error => {
        console.error(error);
    });


</script>

