<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Quotation_model extends CI_Model {

    // Save quotation and items in the database
    public function saveQuotation($client, $items) {
        // Begin a transaction to ensure all operations are atomic
        $this->db->trans_start();

        $new_quotationID = 'QT-' . '200' . rand(1,9);
        $this->db->insert('quotations', [
            // 'quotation_id' => 'QT' . strtoupper(uniqid()), 
            // 'quotation_id' => 'QT' . str_pad($this->db->insert_id(), 6, '0', STR_PAD_LEFT),
            'quotation_id' => $new_quotationID,
            'name' => $client['name'],
            'address' => $client['address'],
            'term_conditon' => $client['term_conditon'],
            'grand_total' => $client['grand_total'],
            'created_at' => date('Y-m-d H:i:s')
        ]);
        if (!$this->db->affected_rows()) {
            log_message('error', 'Failed to insert quotation: ' . $this->db->last_query());
            return false;
        }

        $quotation_id = $this->db->insert_id(); // Get the inserted quotation ID

        if ($quotation_id) {
            // Insert items into the `items` table
            foreach ($items as $item) {
                $this->db->insert('items', [
                    'quotation_id' => $quotation_id,
                    'product_name' => $item['product_name'],
                    'product_desc' => $item['product_desc'],
                    'product_qty' => $item['product_qty'],
                    'product_price' => $item['product_price'],
                    'total' => $item['total']
                ]);
            }
        }

        // Complete the transaction
        $this->db->trans_complete();

        // Check the status of the transaction
        if ($this->db->trans_status() === FALSE) {
            return false;
        }

        return $quotation_id;
    }


    public function getQuotationById($id) {
        return $this->db->get_where('quotations', ['id' => $id])->row_array();
    }
    
    public function getItemsByQuotationId($quotation_id) {
        return $this->db->get_where('items', ['quotation_id' => $quotation_id])->result_array();
    }
    public function getItemsByCompany($id) {
        return $this->db->get_where('company', ['id' => $id])->row_array();
    }



    // Delete Quotation Function 
    public function deleteQuotation($id) {
        $this->db->where('id', $id);
        $this->db->delete('quotations');
    }

    // Delete related items from the items table using the quotation ID
    public function deleteQuotationItems($quotation_id) {
        $this->db->where('quotation_id', $quotation_id);
        $this->db->delete('items');
    }
    
}
