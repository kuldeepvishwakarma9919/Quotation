<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Settings extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Settings_model'); // Load the model
    }

    public function settings(){

        $data['quotations'] = $this->db->get('quotations')->result_array();
        $this->load->view('settings',$data);
    }

    // Save company settings
    public function save_company_settings() {
        // Debug the incoming data
        log_message('debug', 'POST data: ' . print_r($_POST, true));
        log_message('debug', 'FILES data: ' . print_r($_FILES, true));
    
        // Check if the request is AJAX
        if (!$this->input->is_ajax_request()) {
            show_error('No direct access allowed');
        }
    
        // Handle file upload for company logo
        $config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['max_size'] = 2048; // 2MB max size
        $this->load->library('upload', $config);
    
        $company_logo = '';
        if (!empty($_FILES['company_logo']['name'])) {
            if ($this->upload->do_upload('company_logo')) {
                $upload_data = $this->upload->data();
                $company_logo = $upload_data['file_name']; // Save the file name
            } else {
                log_message('error', 'File Upload Error: ' . $this->upload->display_errors());
                echo json_encode(['status' => 'error', 'message' => $this->upload->display_errors()]);
                return;
            }
        }
    
        // Prepare data to insert
        $data = [
            'company_brand' => $this->input->post('comapny_brand'),
            'company_email' => $this->input->post('comapny_email'),
            'company_number' => $this->input->post('company_number'),
            'company_logo' => $company_logo,
            'company_address' => $this->input->post('company_address')
        ];
    
        // Debug the data before inserting
        log_message('debug', 'Data to Insert: ' . print_r($data, true));
    
        // Insert the data
        if ($this->Settings_model->insert_company_settings($data)) {
            echo json_encode(['status' => 'success', 'message' => 'Company settings saved successfully.']);
        } else {
            log_message('error', 'Database Insert Error: ' . $this->db->last_query());
            echo json_encode(['status' => 'error', 'message' => 'Failed to save company settings.']);
        }
    }
    
}
