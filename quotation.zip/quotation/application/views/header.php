<nav class="navbar navbar-expand-lg navbar-light bg-white shadow p-3 fixed-top">
            <div class="container-fluid">
                <button class="btn btn-dark me-2" id="toggleSidebar">
                    ☰
                </button>

                <a class="navbar-brand" href="#">Invoice Quotation</a>
            </div>
        </nav>