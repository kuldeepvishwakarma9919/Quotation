<div class="sidebar" id="sidebar">
    <h4 class="text-center py-3 text-white bg-dark">Menu</h4>
    <a href="<?=base_url()?>" class="sidebar-link">
        <i class="fas fa-home"></i> Dashboard
    </a>
    <a href="<?=base_url()?>create-quotation" class="sidebar-link">
        <i class="fas fa-file-alt"></i> Create Quotation
    </a>
    <a href="<?=base_url()?>view-quotation" class="sidebar-link">
        <i class="fas fa-eye"></i> View Quotations
    </a>
    <a href="<?= base_url() ?>settings" class="sidebar-link">
        <i class="fas fa-cogs"></i> Settings
    </a>
    </div>
