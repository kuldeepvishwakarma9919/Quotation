<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quotation</title>
    <?php $this->load->view('head') ?>
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <!-- FontAwesome CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="overlay" id="overlay"></div>
    <!-- Sidebar -->
   <?php $this->load->view('sidebar') ?>

    <!-- Content -->
    <div class="content">
      <?php $this->load->view('header') ?>
      <div class="container Custom-body">
        <div class="row">
            <h2 class="text-center mb-4">View Quotation</h2>
            <div class="col-md-12">
                <table id="quotationTable" class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>S.NO</th>
                            <th>Name</th>
                            <th>Address</th>
                            <th>Grand Total</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="data-container">
                        <!-- Data will be loaded dynamically -->
                    </tbody>
                </table>
            </div>
        </div>
      </div>
    </div>
</div>

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

<script>
$(document).ready(function () {
    // Sidebar toggle functionality
    $('#toggleSidebar').on('click', function () {
        $('#sidebar').toggleClass('active');
        $('#overlay').toggleClass('active');
    });

    $('#overlay').on('click', function () {
        $('#sidebar').removeClass('active');
        $('#overlay').removeClass('active');
    });

    // Fetch data and populate DataTable
    $('#quotationTable').DataTable({
        "ajax": {
            "url": 'Home/fetch_data',
            "type": 'GET',
            "dataSrc": function (json) {
                if (json.status === 'success') {
                    return json.data;
                } else {
                    alert('No data found');
                    return [];
                }
            }
        },
        "columns": [
            { "data": null, render: (data, type, row, meta) => meta.row + 1 }, // S.NO
            { "data": "name" },
            { "data": "address" },
            { "data": "grand_total" },
            { "data": null, render: function (data) {
                return `
                    <button class="btn btn-success" onclick="printQuotation(${data.id})">
                        <i class="fa-solid fa-print"></i>
                    </button>
                    <button class="btn btn-danger" onclick="deleteQuotation(${data.id})">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                `;
            }}
        ],
        "paging": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "lengthMenu": [5, 10, 25, 50]
    });
});

function printQuotation(id) {
    const printWindow = window.open('Home/print_quotation/' + id, '_blank');
    printWindow.onload = function () {
        printWindow.print();
    };
}

function deleteQuotation(id) {
    if (confirm('Are you sure you want to delete this quotation?')) {
        $.ajax({
            url: '<?= base_url("home/delete") ?>',
            type: 'POST',
            data: { id: id },
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    alert('Quotation deleted successfully!');
                    location.reload();
                } else {
                    alert('Failed to delete quotation: ' + response.message);
                }
            },
            error: function () {
                alert('An error occurred while deleting the quotation.');
            }
        });
    }
}
</script>
</body>
</html>
