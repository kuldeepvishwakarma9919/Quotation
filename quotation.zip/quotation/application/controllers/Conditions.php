<?php
defined('BASEPATH') OR exit('No direct script access allowed'); 

class Conditions extends CI_Controller{
    public function save_conditions() {
        // Retrieve data from POST
        $data = [
            'term_text' => $this->input->post('term_text'),
        ];
        $query_run = $this->db->insert('terms_conditions',$data);
        // Insert data into the database
        if ($query_run) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error']);
        }
    }
}