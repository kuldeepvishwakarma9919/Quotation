
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print Quotation</title>
    <?php $this->load->view('head')?>
    <style>
        body{
            /* font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif; */
            /* font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif; */
            /* font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif; */
            font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;
            /* font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif; */
            /* font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif; */


            
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center ">
        <div class="col-md-10 border shadow-lg p-3 rounded mt-4">
            <div class="row align-items-center mt-5">
                <div class="col-md-3 text-center">
                <img style="width: 100px; height: 100px; border-radius: 50%;" src="<?=base_url()?>uploads/<?=$company['company_logo']?>" alt="">
                 </div>
                <div class="col-md-6">
                <div class="header">
                <h2><?=$company['company_brand']?></h2>
                <p><?=$company['company_address']?></p>
                <p>+91 <?=$company['company_number']?> | <?=$company['company_email']?></p>
                 </div>
                 </div>
                 <div class="col-md-3">
                <h3><b>quotation : </b></h3>
                </div>
            </div>

            <hr>

            <div class="row justify-content-between">
                <div class="col-md-6">
                   <p><strong>To:</strong> <?= $quotation['name'] ?><br>
                      <?= $quotation['address']?>
                    </p>

                   <br>
                   <br>
                   <br>
                   <p> Dear Sir/Madam <br>
                    Thank you for your valuable inquiry. We are pleased to quote as below.
                   </p>
                </div>
                <div class="col-md-6 text-end">
                    <p><strong>Quotation #:</strong> <?= $quotation['id'] ?><br>
                    <strong>Date:</strong> <?= date('d/m/Y', strtotime($quotation['created_at'])) ?></p> 
                </div>
            </div>
    <!-- <h3>Quotation</h3> -->
    
   

    

    <table class="quotation-table table">
        <thead>
            <tr>
                <th>#</th>
                <th>Description</th>
                <th>Qty</th>
                <th>Price</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($items as $index => $item): ?>
                <tr>
                    <td><?= $index + 1 ?></td>
                    <td><b><?= $item['product_name'] ?></b><br><?= $item['product_desc'] ?></td>
                    <td><?= $item['product_qty'] ?></td>
                    <td>₹<?= number_format($item['product_price'], 2) ?></td>
                    <td>₹<?= number_format($item['total'], 2) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="4" class="total">Grand Total:</td>
                <td>₹<?= number_format($quotation['grand_total'], 2) ?></td>
            </tr>
        </tfoot>
    </table>

    <div class="footer">
        <p>Thank you for your business!</p>
    </div>

    

    <div>
        <h5><b>Payment Installment Plan</b></h5>


        <p><b>Fisrt Installment:</b> 20,000 (Advance)</p>
        <p><b>Second Installment:</b> Rs 20,000 (After Completion Pipe line Fitting)</p>
        <p><b>Third Installment:</b> Rs 20,000 (Leadge Wall & Line Testing)</p>
        <p><b>Fourth Installment:</b> Clear All Dues ( Complete Cenetary Fitting)</p>
    </div>

    <br><br>
    


    <div>
        <h5><b>Terms & Conditions:</b></h5>

     
        <?php if ($quotation['term_conditon'] == '') { ?>
            <p>Payment Installment Process</p>
            <p>We are only Responsible for our Plumbring Works</p>
            <p>If you get any additional plumbing work done beyond the tasks mentioned in the list above, you will have to
            pay according to the rate specified for that particular job.</p>
            <p>NO Civil Work, No Water Proof, No Core Cutting are Covered.</p>
            <p>In this quotation, only pipeline work is included; no equipment is included.</p>
       <?php }  else { 
          echo $quotation['term_conditon'];
       } ?>
         
    </div>

    <br><br>

    <div class="text-end">
        <h5><b>For: A. R. Plumbing Work</b></h5>

        <span>Signature</span>
        <p>AUTHORIZED SIGNATURE</p>
    </div>

            
        </div>
        </div>
    </div>

    <hr>



</body>
</html>
