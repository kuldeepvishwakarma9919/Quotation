

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quotation</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
   <?php $this->load->view('head') ?>
   <style>
    .card {
    border-radius: 10px;
    overflow: hidden;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
}

.card-header {
    border-bottom: 2px solid #dee2e6;
    text-align: center;
    font-weight: bold;
}

.card-body p {
    font-size: 14px;
    color: #555;
    margin-bottom: 8px;
}

.btn-primary {
    background-color: #007bff;
    border-color: #007bff;
    border-radius: 5px;
    padding: 5px 20px;
}

.btn-primary:hover {
    background-color: #0056b3;
    border-color: #0056b3;
}

    .custom-card {
        border: 1px solid #e3e3e3;
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
        transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
    }

    .custom-card:hover {
        transform: translateY(-5px);
        box-shadow: 0px 6px 20px rgba(0, 0, 0, 0.15);
    }

    .custom-card-header {
        background: linear-gradient(90deg, #007bff, #0056b3);
        color: white;
        padding: 16px;
        font-weight: bold;
        font-size: 18px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .custom-card-header a {
        color: white;
        font-size: 18px;
        text-decoration: none;
    }

    .custom-card-body {
        padding: 16px;
        font-size: 14px;
    }

    .custom-card-body p {
        margin-bottom: 8px;
        line-height: 1.5;
        color: #555;
    }

    .custom-card-body h6 {
        font-weight: bold;
        color: #333;
        margin-bottom: 12px;
    }

    .custom-list-group {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .custom-list-group li {
        /* display: flex;
        justify-content: space-between;
        align-items: center; */
        padding: 8px 0;
        border-bottom: 1px solid #f0f0f0;
        font-size: 14px;
    }

    .custom-list-group li:last-child {
        border-bottom: none;
    }

    .custom-list-group .no-data {
        text-align: center;
        color: #999;
        font-style: italic;
    }

    .custom-card-footer {
        background-color: #f8f9fa;
        text-align: center;
        padding: 12px;
    }

    .custom-card-footer a {
        display: inline-block;
        padding: 8px 16px;
        color: white;
        background-color: #007bff;
        border-radius: 6px;
        font-size: 14px;
        text-decoration: none;
        transition: background-color 0.2s ease-in-out;
    }

    .custom-card-footer a:hover {
        background-color: #0056b3;
    }
</style>
</head>
<body >
<div class="overlay" id="overlay"></div>
    <!-- Sidebar -->
    <?php $this->load->view('sidebar') ?>

    <!-- Content -->
    <div class="content">
       <?php $this->load->view('header') ?>



       <div class="container mt-5 Custom-body">
        <h2 class="text-center mb-4">DataTable Example</h2>
        <table id="quotationTable" class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Client Name</th>
                    <th>Grand Total (USD)</th>
                    <th>Items</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($quotations)): ?>
                    <?php foreach ($quotations as $val): ?>
                        <tr>
                            <td><?= htmlspecialchars($val['id']) ?></td>
                            <td><?= htmlspecialchars($val['name']) ?></td>
                            <td><?= htmlspecialchars($val['grand_total']) ?></td>
                            <td>
                                <?php
                                $items = !empty($val['product_name']) ? explode(',', $val['product_name']) : [];
                                $quantities = !empty($val['product_desc']) ? explode(',', $val['product_desc']) : [];
                                $prices = !empty($val['product_price']) ? explode(',', $val['product_price']) : [];
                                ?>
                                <ul class="list-unstyled">
                                    <?php if (!empty($items)): ?>
                                        <?php foreach ($items as $key => $item): ?>
                                            <li>
                                                <strong>Product:</strong> <?= htmlspecialchars($item) ?><br>
                                                <strong>Desc:</strong> <?= htmlspecialchars($quantities[$key] ?? 'N/A') ?><br>
                                                <strong>Price:</strong> <?= htmlspecialchars($prices[$key] ?? '0') ?> USD
                                                <hr>
                                            </li>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <li>No data available</li>
                                    <?php endif; ?>
                                </ul>
                            </td>
                            <td>
                                <a href="<?= base_url('quotation/view/') . $val['id'] ?>" class="btn btn-primary btn-sm">View</a>
                                <a href="<?= base_url('edit/') . $val['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="text-center">No quotations available.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>





     

    

    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>


    <script>
        $(document).ready(function () {
            $('#quotationTable').DataTable({
                "paging": true,
                "searching": true,
                "ordering": true,
                "info": true,
                "lengthMenu": [5, 10, 25, 50],
                "columnDefs": [
                    { "orderable": false, "targets": [3, 4] } // Disable ordering for Items & Actions
                ]
            });
        });
    </script>

    <script>
        // Sidebar toggle functionality
        $(document).ready(function () {
            $('#toggleSidebar').on('click', function () {
                $('#sidebar').toggleClass('active');
                $('#overlay').toggleClass('active');
            });

            $('#overlay').on('click', function () {
                $('#sidebar').removeClass('active');
                $('#overlay').removeClass('active');
            });
        });
    </script>
   
</body>
</html>

