

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quotation</title>
   <?php $this->load->view('head') ?>
   <style>
    .card {
    border-radius: 10px;
    overflow: hidden;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
}

.card-header {
    border-bottom: 2px solid #dee2e6;
    text-align: center;
    font-weight: bold;
}

.card-body p {
    font-size: 14px;
    color: #555;
    margin-bottom: 8px;
}

.btn-primary {
    background-color: #007bff;
    border-color: #007bff;
    border-radius: 5px;
    padding: 5px 20px;
}

.btn-primary:hover {
    background-color: #0056b3;
    border-color: #0056b3;
}

   </style>
</head>
<body>
<div class="overlay" id="overlay"></div>
    <!-- Sidebar -->
    <?php $this->load->view('sidebar') ?>

    <!-- Content -->
    <div class="content">
       <?php $this->load->view('header') ?>

      <div class="container Custom-body">

    
    <h2 class="text-center mb-4"><?= isset($quotation) ? 'Edit Quotation' : 'Create Quotation' ?></h2>
<form id="quotationForm" method="post" action="<?= isset($quotation) ? base_url('Home/update') : base_url('Home/save_quotation') ?>">
    <!-- Hidden Field for Quotation ID (For Update) -->
    <?php if (isset($quotation)): ?>
        <input type="hidden" name="quotation_id" value="<?= $quotation['id'] ?>">
    <?php endif; ?>

    <div class="row">
        <div class="col-md-6 mb-3">
            <label for="name" class="form-label">Quotation Name</label>
            <input type="text" class="form-control" id="name" name="name" 
                   value="<?= isset($quotation) ? $quotation['name'] : '' ?>" 
                   placeholder="Quotation Name" required>
        </div>
        <div class="col-md-6 mb-3">
            <label for="date" class="form-label">Quotation Date</label>
            <input type="date" class="form-control" id="date" name="date" 
                   value="<?= isset($quotation) ? $quotation['created_at'] : '' ?>" 
                   placeholder="Quotation Date" required>
        </div>
        <div class="mb-3">
            <label for="address" class="form-label">Quotation Address</label>
            <textarea class="form-control" id="address" name="address" rows="3" 
                      placeholder="Quotation Address" required><?= isset($quotation) ? $quotation['address'] : '' ?></textarea>
        </div>
    </div>

    <!-- Items Section -->
    <div class="mb-3">
        <label>Items</label>
        <div id="itemsContainer">
            <?php if (isset($items) && !empty($items)): ?>
                <?php foreach ($items as $key => $item): ?>
                    <div class="row g-2 item-row">
                        <div class="col-md-6">
                            <input type="text" class="form-control" name="product_name[]" 
                                   value="<?= $item['product_name'] ?>" 
                                   placeholder="Product Name" required>
                        </div>
                        <div class="col-md-3">
                            <input type="number" class="form-control" name="product_qty[]" 
                                   value="<?= $item['product_qty'] ?>" 
                                   placeholder="Product Quantity" required>
                        </div>
                        <div class="col-md-3">
                            <input type="number" class="form-control" name="product_price[]" 
                                   value="<?= $item['product_price'] ?>" 
                                   placeholder="Product Price" required>
                        </div>
                        <div class="col-md-12">
                            <textarea class="form-control" name="product_desc[]" 
                                      placeholder="Product Description" required><?= $item['product_desc'] ?></textarea>
                        </div>
                        <div class="col-md-12 mt-2">
                            <button type="button" class="btn btn-danger removeItem">Remove</button>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="row g-2">
                    <div class="col-md-6">
                        <input type="text" class="form-control" name="product_name[]" 
                               placeholder="Product Name" required>
                    </div>
                    <div class="col-md-3">
                        <input type="number" class="form-control" name="product_qty[]" 
                               placeholder="Product Quantity" required>
                    </div>
                    <div class="col-md-3">
                        <input type="number" class="form-control" name="product_price[]" 
                               placeholder="Product Price" required>
                    </div>
                    <div class="col-md-12">
                        <textarea class="form-control" name="product_desc[]" 
                                  placeholder="Product Description" required></textarea>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="d-flex align-items-center">
        <button type="button" id="addItem" class="btn btn-secondary btn-sm">Add Item</button> &nbsp;
        &nbsp; &nbsp; &nbsp;
        <button type="submit" class="btn btn-primary btn-sm"><?= isset($quotation) ? 'Update Quotation' : 'Save Quotation' ?></button>
    </div>
</form>

</div>


    

      
    </div>

    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

 


<script>
       // Sidebar toggle functionality
       $(document).ready(function () {
            $('#toggleSidebar').on('click', function () {
                $('#sidebar').toggleClass('active');
                $('#overlay').toggleClass('active');
            });

            $('#overlay').on('click', function () {
                $('#sidebar').removeClass('active');
                $('#overlay').removeClass('active');
            });
        });
    </script>
    <script>
        $(document).ready(function () {
    // Add new item rows dynamically
    $('#addItem').on('click', function () {
        $('#itemsContainer').append(`
            <div class="row g-2 mt-2 item-row">
                <div class="col-md-6">
                    <input type="text" class="form-control" name="product_name[]" placeholder="Product Name" required>
                </div>
                <div class="col-md-3">
                    <input type="number" class="form-control" name="product_qty[]" placeholder="Product Quantity" required>
                </div>
                <div class="col-md-3">
                    <input type="number" class="form-control" name="product_price[]" placeholder="Product Price" required>
                </div>
                <div class="col-md-12">
                    <textarea class="form-control" name="product_desc[]" placeholder="Product Description" required></textarea>
                </div>
                <div class="col-md-12 mt-2">
                    <button type="button" class="btn btn-danger removeItem">Remove</button>
                </div>
            </div>
        `);
    });

    // Remove item row dynamically
    $(document).on('click', '.removeItem', function () {
        $(this).closest('.item-row').remove();
    });

});

    </script>

</body>
</html>

