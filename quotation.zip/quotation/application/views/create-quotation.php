<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quotation</title>
    <?php $this->load->view('head') ?>
    <style>
       

        .card {
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border: none;
            border-radius: 10px;
        }

        .form-control {
            border-radius: 5px;
        }

        .btn {
            border-radius: 5px;
        }

        .btn-secondary {
            background-color: #6c757d;
            color: #fff;
            border: none;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
        }

        .btn-primary {
            background-color: #007bff;
            color: #fff;
            border: none;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        .removeItem {
            border-radius: 5px;
        }

        #itemsContainer {
            margin-top: 20px;
        }

        .item-row {
            border-bottom: 1px solid #ddd;
            padding-bottom: 15px;
        }

        .item-row:last-child {
            border-bottom: none;
        }
    </style>


<!-- <script src="ckeditor5/build/ckeditor.js"></script> -->
 <!-- <script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script> -->
</head>
<body>
<div class="overlay" id="overlay"></div>

<!-- Sidebar -->
<?php $this->load->view('sidebar') ?>

<!-- Content -->
<div class="content">
    <?php $this->load->view('header') ?>

    <div class="container Custom-body">
      <h2 class="text-center mb-4">Create Quotation</h2>
        <form id="quotationForm">
            <div class="row justify-content-center">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="name" class="form-label">Quotation Name</label>
                                            <input type="text" class="form-control" id="name" name="name">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="date" class="form-label">Quotation Date</label>
                                            <input type="date" class="form-control" id="date" name="date">
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label for="address" class="form-label">Quotation Address</label>
                                        <textarea class="form-control" id="address" name="address" rows="3"></textarea>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <label for="">Terms And Conditions</label>
                                     <textarea name="term_conditon" id="term_conditon" class="form-control editor"><?=$termcondition['term_text']?></textarea>
                                </div>
                            </div>

                            <hr>

                            <!-- Product Items -->
                            <div id="itemsContainer">
                                <div class="row g-2 item-row">

                                 <div class="row">
                                    <div class="col-md-4">
                                    <div class="col-md-12">
                                        <input type="text" class="form-control" name="product_name[]" placeholder="Product Name" required>
                                    </div>
                                    <div class="col-md-12">
                                        <input type="number" class="form-control" name="product_qty[]" placeholder="Product Quantity" required>
                                    </div>
                                    <div class="col-md-12">
                                        <input type="number" class="form-control" name="product_price[]" placeholder="Product Price" required>
                                    </div>
                                    </div>
                                    <div class="col-md-8">
                                    <div class="col-md-12">
                                        <textarea class="form-control editor" name="product_desc[]" placeholder="Product Description" rows="4" ></textarea>
                                    </div>
                                    </div>
                                 </div>
                                    
                                    
                                </div>
                            </div>

                            <div class="mt-4 d-flex justify-content-between">
                                <button type="button" id="addItem" class="btn btn-secondary btn-sm">Add Item</button>
                                <button type="submit" class="btn btn-primary btn-sm">Save Quotation</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
<script>
    $(document).ready(function () {


        function initializeEditors() {
        document.querySelectorAll('.editor:not(.initialized)').forEach(editorElement => {
            ClassicEditor
                .create(editorElement)
                .then(editor => {
                    editorElement.classList.add('initialized');
                })
                .catch(error => {
                    console.error(error);
                });
        });
    }

    // Add new item row on button click
    $('#addItem').on('click', function () {
        $('#itemsContainer').append(`
            <div class="row g-2 mt-3 item-row">
                <div class="col-md-4">
                    <div class="col-md-12">
                        <input type="text" class="form-control" name="product_name[]" placeholder="Product Name" required>
                    </div>
                    <div class="col-md-12">
                        <input type="number" class="form-control" name="product_qty[]" placeholder="Product Quantity" required>
                    </div>
                    <div class="col-md-12">
                        <input type="number" class="form-control" name="product_price[]" placeholder="Product Price" required>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="col-md-12">
                        <textarea class="form-control editor" name="product_desc[]" placeholder="Product Description" rows="4"></textarea>
                    </div>
                </div>
                <div class="col-md-12 mt-2 text-end">
                    <button type="button" class="btn btn-danger btn-sm removeItem">Remove</button>
                </div>
            </div>
        `);

        // Initialize ClassicEditor for newly added textareas
        initializeEditors();
    });

    // Remove item row on button click
    $('#itemsContainer').on('click', '.removeItem', function () {
        $(this).closest('.item-row').remove();
    });

    // Initialize ClassicEditor for the existing textarea(s) on page load
    initializeEditors();
        // Add new item rows dynamically
        // $('#addItem').on('click', function () {
        //     $('#itemsContainer').append(`
        //         <div class="row g-2 mt-3 item-row">
        //             <div class="col-md-4">
        //                 <div class="col-md-12">
        //                 <input type="text" class="form-control" name="product_name[]" placeholder="Product Name" required>
        //                 </div>
        //                 <div class="col-md-12">
        //                 <input type="number" class="form-control" name="product_qty[]" placeholder="Product Quantity" required>
        //                 </div>
        //                 <div class="col-md-12">
        //                 <input type="number" class="form-control" name="product_price[]" placeholder="Product Price" required>
        //                 </div> 
        //             </div>
        //             <div class="col-md-8">
        //                 <div class="col-md-12">
        //                 <textarea class="form-control" name="product_desc[]" placeholder="Product Description" rows="4" required></textarea>
        //                </div>
        //             </div>
        //             <div class="col-md-12 mt-2 text-end">
        //                 <button type="button" class="btn btn-danger btn-sm removeItem">Remove</button>
        //             </div>
        //         </div>
        //     `);
        // });

        // // Remove item row
        // $(document).on('click', '.removeItem', function () {
        //     $(this).closest('.item-row').remove();
        // });

        // Form submission
        $('#quotationForm').on('submit', function (e) {
            e.preventDefault();

            const client = {
                quotation_id: $('#quotation_id').val(),
                name: $('#name').val(),
                address: $('#address').val(),
                term_conditon: $('#term_conditon').val(),
                grand_total: 0
            };

            const items = [];
            let grandTotal = 0;

            $('#itemsContainer .item-row').each(function () {
                const product_name = $(this).find('input[name="product_name[]"]').val();
                const product_desc = $(this).find('textarea[name="product_desc[]"]').val();
                const product_qty = parseInt($(this).find('input[name="product_qty[]"]').val());
                const product_price = parseFloat($(this).find('input[name="product_price[]"]').val());
                const total = product_qty * product_price;

                items.push({ product_name, product_desc, product_qty, product_price, total });
                grandTotal += total;
            });

            client.grand_total = grandTotal;
            const dataToSend = JSON.stringify({ client, items });

            $.ajax({
                url: 'Home/save_quotation',
                type: 'POST',
                contentType: 'application/json',
                data: dataToSend,
                success: function (response) {
                    const res = JSON.parse(response);
                    if (res.status === 'success') {
                        alert('Quotation saved successfully! ID: ' + res.quotation_id);
                        $('#quotationForm')[0].reset();
                        $('#itemsContainer').html('');
                    } else {
                        alert('Error: ' + res.message);
                    }
                },
                error: function (err) {
                    console.error(err);
                    alert('Error sending data.');
                }
            });
        });
    });
</script>
<script>
    function printQuotation(id) {
        const printWindow = window.open('Home/print_quotation/' + id, '_blank');
        printWindow.onload = function () {
            printWindow.print();
        };
    }
</script>
</body>
</html>
